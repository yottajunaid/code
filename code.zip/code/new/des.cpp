#include <iostream>
#include <string>
using namespace std;

string permute(string s, int p[], int n) {
    string res = "";
    for (int i = 0; i < n; i++) res += s[p[i] - 1];
    return res;
}

string shiftLeft(string s, int n) {
    return s.substr(n) + s.substr(0, n);
}

string xorStr(string a, string b) {
    string res = "";
    for (int i = 0; i < a.size(); i++) res += (a[i] == b[i] ? '0' : '1');
    return res;
}

string sbox(string s, int box[4][4]) {
    int r = (s[0] - '0') * 2 + (s[3] - '0');
    int c = (s[1] - '0') * 2 + (s[2] - '0');
    int val = box[r][c];
    return string(1, (val / 2) + '0') + string(1, (val % 2) + '0');
}

string fk(string bits, string key) {
    int EP[] = {4, 1, 2, 3, 2, 3, 4, 1}, P4[] = {2, 4, 3, 1};
    int S0[4][4] = {{1,0,3,2},{3,2,1,0},{0,2,1,3},{3,1,3,2}};
    int S1[4][4] = {{0,1,2,3},{2,0,1,3},{3,0,1,0},{2,1,0,3}};

    string L = bits.substr(0, 4), R = bits.substr(4, 4);
    string x = xorStr(permute(R, EP, 8), key);
    string sOut = sbox(x.substr(0, 4), S0) + sbox(x.substr(4, 4), S1);
    return xorStr(L, permute(sOut, P4, 4)) + R;
}

string runSDES(string text, string k1, string k2) {
    int IP[] = {2, 6, 3, 1, 4, 8, 5, 7}, IP_inv[] = {4, 1, 3, 5, 7, 2, 8, 6};
    string t = permute(text, IP, 8);
    t = fk(t, k1);
    t = t.substr(4, 4) + t.substr(0, 4);
    t = fk(t, k2);
    return permute(t, IP_inv, 8);
}

int main() {
    string pt, key;
    cout << "Enter 8-bit Plaintext: ";
    cin >> pt;
    cout << "Enter 10-bit Key: ";
    cin >> key;

    int P10[] = {3, 5, 2, 7, 4, 10, 1, 9, 8, 6}, P8[] = {6, 3, 7, 4, 8, 5, 10, 9};
    string p10 = permute(key, P10, 10);
    string ls1 = shiftLeft(p10.substr(0, 5), 1) + shiftLeft(p10.substr(5, 5), 1);
    string k1 = permute(ls1, P8, 8);
    string ls2 = shiftLeft(ls1.substr(0, 5), 2) + shiftLeft(ls1.substr(5, 5), 2);
    string k2 = permute(ls2, P8, 8);

    string enc = runSDES(pt, k1, k2);
    string dec = runSDES(enc, k2, k1);
    cout << "Encrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}