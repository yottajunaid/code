#include <iostream>
#include <string>
using namespace std;

int main() {
    string msg, key, enc = "", dec = "";
    cout << "Enter Plaintext (UPPERCASE): ";
    cin >> msg;
    cout << "Enter Key (UPPERCASE): ";
    cin >> key;

    for (int i = 0; i < msg.size(); i++)
        enc += char((msg[i] - 'A' + key[i % key.size()] - 'A') % 26 + 'A');

    for (int i = 0; i < enc.size(); i++)
        dec += char((enc[i] - 'A' - (key[i % key.size()] - 'A') + 26) % 26 + 'A');

    cout << "Encrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}