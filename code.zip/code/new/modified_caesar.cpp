#include <iostream>
#include <string>
using namespace std;

string shiftText(string text, int k) {
    k = (k % 26 + 26) % 26;
    for (char &c : text) {
        if (isupper(c)) c = (c - 'A' + k) % 26 + 'A';
        else if (islower(c)) c = (c - 'a' + k) % 26 + 'a';
    }
    return text;
}

int main() {
    string msg;
    int key;
    cout << "Enter Plaintext: ";
    getline(cin, msg);
    cout << "Enter Shift Key: ";
    cin >> key;

    string enc = shiftText(msg, key);
    string dec = shiftText(enc, -key);
    cout << "Encrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}