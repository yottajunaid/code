#include <iostream>
using namespace std;

long long modPow(long long b, long long e, long long m) {
    long long res = 1;
    while (e > 0) {
        if (e % 2 == 1) res = (res * b) % m;
        b = (b * b) % m;
        e /= 2;
    }
    return res;
}

long long modInv(long long a, long long m) {
    for (long long x = 1; x < m; x++)
        if ((a * x) % m == 1) return x;
    return -1;
}

int main() {
    long long p, g, x, m, k;
    cout << "Enter prime (p) and primitive root (g): ";
    cin >> p >> g;
    cout << "Enter private key (x): ";
    cin >> x;

    long long y = modPow(g, x, p);
    cout << "Public Key (y): " << y << endl;

    cout << "Enter message (m) and random k (gcd(k, p-1)=1): ";
    cin >> m >> k;

    long long r = modPow(g, k, p);
    long long k_inv = modInv(k, p - 1);
    long long s = (k_inv * (m - x * r)) % (p - 1);
    if (s < 0) s += (p - 1);

    cout << "Signature (r, s): (" << r << ", " << s << ")\n";

    long long v1 = (modPow(y, r, p) * modPow(r, s, p)) % p;
    long long v2 = modPow(g, m, p);
    cout << (v1 == v2 ? "Signature Valid!" : "Signature Invalid!") << endl;
    return 0;
}