#include <iostream>
#include <string>
using namespace std;

char mat[5][5];

void findPos(char c, int &r, int &col) {
    if (c == 'J') c = 'I';
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
            if (mat[i][j] == c) { r = i; col = j; return; }
}

string process(string text, int dir) { // dir = 1 (Encrypt), 4 (Decrypt)
    string res = "";
    for (int i = 0; i < text.size(); i += 2) {
        int r1, c1, r2, c2;
        findPos(text[i], r1, c1);
        findPos(text[i + 1], r2, c2);
        if (r1 == r2) {
            res += mat[r1][(c1 + dir) % 5];
            res += mat[r2][(c2 + dir) % 5];
        } else if (c1 == c2) {
            res += mat[(r1 + dir) % 5][c1];
            res += mat[(r2 + dir) % 5][c2];
        } else {
            res += mat[r1][c2];
            res += mat[r2][c1];
        }
    }
    return res;
}

int main() {
    string key, msg;
    cout << "Enter Key (UPPERCASE): ";
    cin >> key;
    cout << "Enter Plaintext (UPPERCASE): ";
    cin >> msg;

    // Build 5x5 Matrix
    bool used[26] = {false};
    used['J' - 'A'] = true;
    string letters = "";
    for (char c : key + "ABCDEFGHIKLMNOPQRSTUVWXYZ") {
        if (c == 'J') c = 'I';
        if (!used[c - 'A']) { used[c - 'A'] = true; letters += c; }
    }

    cout << "\n5x5 Key Matrix:\n";
    for (int i = 0; i < 25; i++) {
        mat[i / 5][i % 5] = letters[i];
        cout << letters[i] << (i % 5 == 4 ? "\n" : " ");
    }

    // Prepare digraphs
    string clean = "";
    for (int i = 0; i < msg.size(); i++) {
        clean += (msg[i] == 'J' ? 'I' : msg[i]);
        if (i + 1 < msg.size() && msg[i] == msg[i + 1]) clean += 'X';
    }
    if (clean.size() % 2 != 0) clean += 'X';

    string enc = process(clean, 1);
    string dec = process(enc, 4);
    cout << "\nEncrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}