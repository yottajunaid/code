#include <iostream>
using namespace std;

int main() {
    int a, m;
    cout << "Enter number (a) and modulo (m): ";
    cin >> a >> m;

    int r1 = m, r2 = a, t1 = 0, t2 = 1;
    while (r2 > 0) {
        int q = r1 / r2;
        int r = r1 - q * r2;
        r1 = r2; r2 = r;

        int t = t1 - q * t2;
        t1 = t2; t2 = t;
    }

    cout << "GCD: " << r1 << endl;
    if (r1 == 1)
        cout << "Multiplicative Inverse: " << (t1 % m + m) % m << endl;
    else
        cout << "Inverse does not exist." << endl;
    return 0;
}