#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    string msg, key;
    cout << "Enter Plaintext (no spaces): ";
    cin >> msg;
    cout << "Enter Key (e.g. HACK): ";
    cin >> key;

    int cols = key.size();
    int rows = (msg.size() + cols - 1) / cols;
    while (msg.size() < rows * cols) msg += 'X'; // Padding

    vector<vector<char>> mat(rows, vector<char>(cols));
    int k = 0;
    cout << "\nMatrix:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            mat[i][j] = msg[k++];
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    vector<pair<char, int>> order;
    for (int j = 0; j < cols; j++) order.push_back({key[j], j});
    sort(order.begin(), order.end());

    // Encryption
    string enc = "";
    for (auto p : order)
        for (int i = 0; i < rows; i++)
            enc += mat[i][p.second];

    // Decryption
    vector<vector<char>> dmat(rows, vector<char>(cols));
    k = 0;
    for (auto p : order)
        for (int i = 0; i < rows; i++)
            dmat[i][p.second] = enc[k++];

    string dec = "";
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            dec += dmat[i][j];

    cout << "\nEncrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}