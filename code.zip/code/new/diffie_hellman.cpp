#include <iostream>
using namespace std;

long long modPow(long long b, long long e, long long m) {
    long long res = 1;
    while (e > 0) {
        if (e % 2 == 1) res = (res * b) % m;
        b = (b * b) % m;
        e /= 2;
    }
    return res;
}

int main() {
    long long p, g, a, b;
    cout << "Enter prime (p) and primitive root (g): ";
    cin >> p >> g;
    cout << "Enter Alice's and Bob's private keys (a, b): ";
    cin >> a >> b;

    long long A = modPow(g, a, p);
    long long B = modPow(g, b, p);
    cout << "Alice Public Key: " << A << "\nBob Public Key: " << B << endl;
    cout << "Alice Shared Secret: " << modPow(B, a, p) << endl;
    cout << "Bob Shared Secret: " << modPow(A, b, p) << endl;
    return 0;
}