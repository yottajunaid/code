#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    string msg;
    int rails;
    cout << "Enter Plaintext (no spaces): ";
    cin >> msg;
    cout << "Enter number of rails: ";
    cin >> rails;

    int n = msg.size();
    vector<vector<char>> grid(rails, vector<char>(n, '\n'));

    // Encryption
    int r = 0, dir = 1;
    for (int c = 0; c < n; c++) {
        grid[r][c] = msg[c];
        if (r == 0) dir = 1;
        else if (r == rails - 1) dir = -1;
        if (rails > 1) r += dir;
    }
    string enc = "";
    for (int i = 0; i < rails; i++)
        for (int j = 0; j < n; j++)
            if (grid[i][j] != '\n') enc += grid[i][j];

    // Decryption
    vector<vector<char>> dgrid(rails, vector<char>(n, '\n'));
    r = 0; dir = 1;
    for (int c = 0; c < n; c++) {
        dgrid[r][c] = '*';
        if (r == 0) dir = 1;
        else if (r == rails - 1) dir = -1;
        if (rails > 1) r += dir;
    }
    int idx = 0;
    for (int i = 0; i < rails; i++)
        for (int j = 0; j < n; j++)
            if (dgrid[i][j] == '*') dgrid[i][j] = enc[idx++];

    string dec = "";
    r = 0; dir = 1;
    for (int c = 0; c < n; c++) {
        dec += dgrid[r][c];
        if (r == 0) dir = 1;
        else if (r == rails - 1) dir = -1;
        if (rails > 1) r += dir;
    }

    cout << "Encrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}