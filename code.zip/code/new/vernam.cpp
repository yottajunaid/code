#include <iostream>
#include <string>
using namespace std;

int main() {
    string msg, key, enc = "", dec = "";
    cout << "Enter Plaintext: ";
    cin >> msg;
    cout << "Enter Key (same length): ";
    cin >> key;

    cout << "Encrypted (ASCII codes): ";
    for (int i = 0; i < msg.size(); i++) {
        char c = msg[i] ^ key[i];
        enc += c;
        cout << (int)c << " ";
    }

    for (int i = 0; i < enc.size(); i++)
        dec += enc[i] ^ key[i];

    cout << "\nDecrypted: " << dec << endl;
    return 0;
}