#include <iostream>
#include <numeric>
#include <cmath>

using namespace std;

int main() {
     int p; int q; int n; 
     int phi; int pub; int pri; int msg; 
     int enc; int dec;
     cout << "Enter value of P: " << endl;
     cin >> p;
     cout << "Enter value of Q: " << endl;
     cin >> q;

     n = p * q;
     cout << n << endl;

     phi = (p - 1) * (q - 1);
     cout << phi << endl;
     
     for (pub = 2; pub < phi; pub++){
        if (gcd(phi , pub) == 1){
            break;
        }
     }
     cout << "Public Key : " << pub << endl;
     
     for (pri = 1; pri <= 10; pri++){
        if ((pub * pri) % phi == 1){
            break;
        }
     }
     cout << "Private Key : " << pri << endl;
     
     cout << "Enter the message : " << endl;
     cin >> msg;

     enc = fmod(pow(msg , pub) , n);
     cout << "Encrypted : " << enc << endl;

     dec = fmod(pow(enc , pri) , n);
     cout << "Decrypted : " << dec << endl;

  return 0;
}
