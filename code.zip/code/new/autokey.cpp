#include <iostream>
#include <string>
using namespace std;

int main() {
    string msg, key, enc = "", dec = "";
    cout << "Enter Plaintext (UPPERCASE): ";
    cin >> msg;
    cout << "Enter Key (UPPERCASE): ";
    cin >> key;

    string encKey = key + msg;
    for (int i = 0; i < msg.size(); i++)
        enc += char((msg[i] - 'A' + encKey[i] - 'A') % 26 + 'A');

    string decKey = key;
    for (int i = 0; i < enc.size(); i++) {
        char p = char((enc[i] - 'A' - (decKey[i] - 'A') + 26) % 26 + 'A');
        dec += p;
        decKey += p;
    }

    cout << "Encrypted: " << enc << "\nDecrypted: " << dec << endl;
    return 0;
}