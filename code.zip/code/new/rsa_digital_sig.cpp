#include <iostream>
using namespace std;

long long modPow(long long b, long long e, long long m) {
    long long res = 1;
    while (e > 0) {
        if (e % 2 == 1) res = (res * b) % m;
        b = (b * b) % m;
        e /= 2;
    }
    return res;
}

int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }

int main() {
    long long p, q, msg;
    cout << "Enter two prime numbers (p and q): ";
    cin >> p >> q;

    long long n = p * q, phi = (p - 1) * (q - 1);
    long long e = 2;
    while (gcd(e, phi) != 1) e++;
    long long d = 1;
    while ((d * e) % phi != 1) d++;

    cout << "Enter message hash (number < " << n << "): ";
    cin >> msg;

    long long sign = modPow(msg, d, n);      // Sign with Private Key
    long long verify = modPow(sign, e, n);   // Verify with Public Key

    cout << "Digital Signature: " << sign << endl;
    cout << "Verified Message: " << verify << endl;
    cout << (verify == msg ? "Signature Valid!" : "Signature Invalid!") << endl;
    return 0;
}