#include <iostream>
using namespace std;

// Euclidean Algorithm
int gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

// Extended Euclidean Algorithm: a*x + b*y = gcd(a, b)
int extGcd(int a, int b, int &x, int &y) {
    if (b == 0) { x = 1; y = 0; return a; }
    int x1, y1, g = extGcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return g;
}

int main() {
    int a, m, x, y;
    cout << "Enter a: "; cin >> a;
    cout << "Enter m: "; cin >> m;

    cout << "GCD: " << gcd(a, m) << '\n';

    int g = extGcd(a, m, x, y);
    cout << "ExtGCD: " << a << "*(" << x << ") + " << m << "*(" << y << ") = " << g << '\n';

    if (g == 1) cout << "Inverse: " << (x % m + m) % m << '\n';
    else cout << "Inverse: Does not exist\n";
}