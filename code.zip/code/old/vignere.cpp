#include <iostream>
#include <string>
using namespace std;

// Vigenère cipher function
string vigenere(string text, string key, bool encrypt) {
    string result = "";
    int keyIndex = 0;
    for (char c : text) {
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            int shift = tolower(key[keyIndex % key.length()]) - 'a';
            if (!encrypt) shift = -shift;
            char ch = (c - base + shift + 26) % 26 + base;
            result += ch;
            keyIndex++;
        } else {
            result += c; // Keep spaces, punctuation as they are
        }
    }
    return result;
}

int main() {
    string message, key;
    cout << "Enter message: ";
    getline(cin, message);
    cout << "Enter key (letters only): ";
    getline(cin, key);

    string encrypted = vigenere(message, key, true);
    string decrypted = vigenere(encrypted, key, false);

    cout << "Encrypted: " << encrypted << endl;
    cout << "Decrypted: " << decrypted << endl;

    return 0;
}
