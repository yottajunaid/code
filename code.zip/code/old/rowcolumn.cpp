#include <iostream>
#include <vector>
#include <sstream>
using namespace std;

int main() {
    int m;
    string kline, s, clean = "";

    cout << "Mode (1:Enc, 2:Dec): "; cin >> m; cin.ignore();
    cout << "Key (numbers space-separated): "; getline(cin, kline);
    cout << "Text: "; getline(cin, s);

    vector<int> key;
    stringstream ss(kline);
    for (int v; ss >> v; ) key.push_back(v);

    for (char c : s) if (isalpha(c)) clean += tolower(c);

    int cols = key.size();
    int rows = (clean.size() + cols - 1) / cols;

    char pad = 'x';
    while (clean.size() < rows * cols) clean += (pad <= 'z' ? pad++ : 'x');

    vector<vector<char>> grid(rows, vector<char>(cols));

    if (m == 1) {
        for (int i = 0; i < clean.size(); ++i)
            grid[i / cols][i % cols] = clean[i];
    } else {
        int idx = 0;
        for (int k = 1; k <= cols; ++k)
            for (int c = 0; c < cols; ++c)
                if (key[c] == k)
                    for (int r = 0; r < rows; ++r)
                        grid[r][c] = clean[idx++];
    }

    cout << "\nMatrix Chart:\n";
    for (int k : key) cout << k << ' ';
    cout << "\n";
    for (auto &r : grid) {
        for (char c : r) cout << c << ' ';
        cout << '\n';
    }

    string res = "";
    if (m == 1) {
        for (int k = 1; k <= cols; ++k)
            for (int c = 0; c < cols; ++c)
                if (key[c] == k)
                    for (int r = 0; r < rows; ++r)
                        res += grid[r][c];
    } else {
        for (auto &r : grid)
            for (char c : r) res += c;
    }

    cout << "\nResult: " << res << '\n';
}