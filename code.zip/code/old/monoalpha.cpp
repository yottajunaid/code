#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char M[] = "QWERTYUIOPASDFGHJKLZXCVBNM", s[256], *p; int c;
    printf("1.Encrypt 2.Decrypt: "); scanf("%d %[^\n]", &c, s);
    for (int i = 0; s[i]; i++) { char b = isupper(s[i]) ? 'A' : islower(s[i]) ? 'a' : 0;
        if (b && c == 1) s[i] = b + (M[s[i] - b] - 'A');
        if (b && c == 2) s[i] = b + ((p = strchr(M, toupper(s[i]))) ? p - M : 0);}
    printf("Result: %s\n", s);
}