#include <stdio.h>
#include <ctype.h>

void cipher(char *s, int k) {
    for (int p = 0; s[p]; p++) {
        if (isupper(s[p])) {
            s[p] = (s[p] - 'A' + (k % 26 + 26)) % 26 + 'A';
        } else if (islower(s[p])) {
            s[p] = (s[p] - 'a' + (k % 26 + 26)) % 26 + 'a';
        }}}

int main() {
    char s[256];
    int choice, k;
    printf("Choose (1: Encr1ypt, 2: Decrypt): ");
    if (scanf("%d", &choice) != 1) return 1;
    printf("Enter key: ");
    if (scanf("%d", &k) != 1) return 1;
    printf("Enter text: ");
    scanf(" %255[^\n]", s);
    cipher(s, choice == 2 ? -k : k);
    printf("Result: %s\n", s);
    return 0;
}