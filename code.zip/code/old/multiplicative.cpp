#include <iostream>
using namespace std;

int main() {
    int m, k, inv = 0;
    string s;

    cout << "Mode (1:Enc, 2:Dec): ";
    cin >> m;
    cout << "Key: ";
    cin >> k;
    cout << "Text: ";
    cin >> s;

    for (int i = 1; i < 26; ++i)
        if ((k * i) % 26 == 1) inv = i;

    for (char &c : s)
        if (isalpha(c))
            c = 'A' + ((toupper(c) - 'A') * (m == 1 ? k : inv)) % 26;

    cout << "Result: " << s << '\n';
}