#include <iostream>
using namespace std;

int main() {
    int m;
    string k, s;

    cout << "Mode (1:Enc, 2:Dec): "; cin >> m;
    cout << "Key (same length as text): "; cin >> k;
    cout << "Text: "; cin >> s;

    for (int i = 0; i < s.size(); ++i) {
        int x = toupper(s[i]) - 'A', y = toupper(k[i]) - 'A';
        s[i] = 'A' + (m == 1 ? (x + y) % 26 : (x - y + 26) % 26);
    }

    cout << "Result: " << s << '\n';
}