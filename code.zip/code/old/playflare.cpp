#include <iostream>
#include <string>

using namespace std;
int main() {
    string p, k, m, a = "ABCDEFGHIKLMNOPQRSTUVWXYZ"; cout << "Enter Plaintext: "; cin >> p; cout << "Enter Key:  " ; cin >> k; cout << p << '\n';
    for (char c : k + a) { c &= ~32;
        if (c == 'J') c = 'I';
        if (c >= 'A' && c <= 'Z' && m.find(c) == string::npos) m += c;}
    for (int i = 0; i < 25; i++)
        cout << m[i] << (i % 5 == 4 ? '\n' : ' ');}