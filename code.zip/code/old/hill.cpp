#include <iostream>
using namespace std;

int main() {
    int m, k[4], d, inv = 0;
    string s, res = "";

    cout << "Mode (1:Enc, 2:Dec): "; cin >> m;
    cout << "Key matrix (4 ints: a b c d): ";
    for (int &x : k) cin >> x;
    cout << "Text: "; cin >> s;

    if (s.size() % 2) s += 'X';

    int det = (k[0] * k[3] - k[1] * k[2]) % 26;
    if (det < 0) det += 26;
    for (int i = 1; i < 26; ++i) if ((det * i) % 26 == 1) inv = i;

    if (m == 2) {
        int ik[4] = {k[3] * inv % 26, (-k[1] % 26 + 26) * inv % 26,
                     (-k[2] % 26 + 26) * inv % 26, k[0] * inv % 26};
        for (int i = 0; i < 4; ++i) k[i] = ik[i];
    }

    for (int i = 0; i < s.size(); i += 2) {
        int p0 = toupper(s[i]) - 'A', p1 = toupper(s[i + 1]) - 'A';
        res += 'A' + (k[0] * p0 + k[1] * p1) % 26;
        res += 'A' + (k[2] * p0 + k[3] * p1) % 26;
    }

    cout << "Result: " << res << '\n';
}