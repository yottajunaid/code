#include <iostream>
#include <string>
using namespace std;

string v(string t, string k , bool e) {
    for (int i = 0, j = 0; i < t.length(); i++) {
        if (isalpha(t[i])){
            char b = islower(t[i]) ? 'a' : 'A';
            int s = k [j++ % k.length()] - (islower(k[j -1]) ? 'a' : 'A');
            t[i] = b + (e? (t[i] -b + s) % 26:
            (t[i] - b - s + 26) % 26);
        }
    }
    return t;
}

int main() {
    int c; string t , k;
    cout << "1. Encrypt\n2.Decrypt\nChoice: "; cin >> c;
    cout << "Text: "; cin.ignore(); getline(cin , t);
    cout << "Key: "; cin >> k;
    cout << "Result: " << v (t , k , c == 1) << endl;
}