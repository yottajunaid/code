#include <iostream>
#include <string>

using namespace std;

int main() {
    string p, k;
    cout << "Plaintext: "; getline(cin, p);
    cout << "Key: "; getline(cin, k);

    int n = p.size(), m = k.size();
    if (!n || !m) return 0;

    for (int i = 0; i < n; ++i) {
        if (m < n)       p[i] = 'A' + (toupper(p[i]) - 'A' + toupper(k[i % m]) - 'A') % 26; // Vigenere
        else if (m == n) p[i] ^= k[i];                                                      // Vernam (XOR)
        else             p[i] = p[i] + (k[i % m] % 26);                                     // Modified Caesar
    }

    cout << "Ciphertext: " << p << '\n';
}