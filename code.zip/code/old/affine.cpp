#include <iostream>
using namespace std;

int main() {
    int m, a, b, inv = 0;
    string s;

    cout << "Mode (1:Enc, 2:Dec): ";
    cin >> m;
    cout << "Key a: ";
    cin >> a;
    cout << "Key b: ";
    cin >> b;
    cout << "Text: ";
    cin >> s;

    for (int i = 1; i < 26; ++i)
        if ((a * i) % 26 == 1) inv = i;

    for (char &c : s)
        if (isalpha(c)) {
            int x = toupper(c) - 'A';
            c = 'A' + (m == 1 ? (a * x + b) % 26 : (inv * (x - b + 26)) % 26);
        }

    cout << "Result: " << s << '\n';
}