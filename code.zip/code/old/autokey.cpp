#include <iostream>
using namespace std;

int main() {
    int m;
    string k, s, res = "";

    cout << "Mode (1:Enc, 2:Dec): "; cin >> m;
    cout << "Key (word or letter): "; cin >> k;
    cout << "Text: "; cin >> s;

    for (int i = 0; i < s.size(); ++i) {
        int cur = toupper(s[i]) - 'A';
        int shift = toupper(k[i]) - 'A';
        int out = m == 1 ? (cur + shift) % 26 : (cur - shift + 26) % 26;
        res += 'A' + out;
        k += (m == 1 ? toupper(s[i]) : 'A' + out);
    }

    cout << "Result: " << res << '\n';
}