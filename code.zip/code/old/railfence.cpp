#include <iostream>
#include <vector>
using namespace std;

int main() {
    int m, k, r = 0, d = 1;
    string s;

    cout << "Mode (1:Enc, 2:Dec): "; cin >> m;
    cout << "Key (rails): "; cin >> k;
    cout << "Text: "; cin >> s;

    int n = s.size();
    vector<int> row(n);
    for (int i = 0; i < n; ++i) {
        row[i] = r;
        if (r == 0) d = 1;
        else if (r == k - 1) d = -1;
        r += d;
    }

    string res(n, ' ');
    if (m == 1) {
        int idx = 0;
        for (int i = 0; i < k; ++i)
            for (int j = 0; j < n; ++j)
                if (row[j] == i) res[idx++] = s[j];
    } else {
        int idx = 0;
        for (int i = 0; i < k; ++i)
            for (int j = 0; j < n; ++j)
                if (row[j] == i) res[j] = s[idx++];
    }

    cout << "Result: " << res << '\n';
}