// ==UserScript==
// @name         LPU Auto Login
// @match        *://internet.lpu.in/24online/*
// @grant        window.close
// ==/UserScript==

setTimeout(() => {
    // If already logged in (redirected page), close the tab
    if (!document.querySelector('input[name="username"]')) {
        window.close();
        return;
    }

    document.querySelector('input[name="username"]').value = 'YOUR_ID@lpu.com';
    document.querySelector('input[name="password"]').value = 'YOUR_INTERNET_PASSWORD';

    const agreeBtn = document.querySelector('input[type="checkbox"]');
    if (agreeBtn && !agreeBtn.checked) agreeBtn.click();

    // Submit the form directly
    const form = document.querySelector('form');
    if (form) form.submit();

}, 500);
