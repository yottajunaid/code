#include <stdio.h>

void encrypt(char *ASCII, int key) { for (int p = 0; ASCII[p] ; p++) 
    {if (ASCII[p]) {ASCII[p] = (ASCII[p] - 65 + key) % 26 + 65;}}}

int main() {char ASCII[] = "KHOOR";
    encrypt(ASCII, 29); printf("%s\n", ASCII);return 0;}